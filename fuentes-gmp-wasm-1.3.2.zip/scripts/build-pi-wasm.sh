#!/bin/bash
set -euo pipefail
workdir=$(cd "${1:?Indica el directorio de compilación}" && pwd)
upstream="$workdir/gmp-wasm-4e372e5a3c4a65f871e1bcaab63c78b29dc80ff8"
sdk="$workdir/emsdk-local/install"
export PATH="$sdk/emscripten:$sdk/bin:$PATH"
export EM_CACHE="$workdir/em-cache"
export EM_CONFIG="$workdir/emscripten-config.py"
export TMPDIR="$workdir/tmp"
export SDKROOT="$(/usr/bin/xcrun --show-sdk-path)"
cat > "$EM_CONFIG" <<EOF
LLVM_ROOT = '$sdk/bin'
BINARYEN_ROOT = '$sdk'
NODE_JS = '$(command -v node)'
EOF
emcc --version
prefix="$workdir/gmp-wasm-install"
mkdir -p "$workdir/gmp-build" "$TMPDIR"
tar -xf "$workdir/gmp-6.3.0.tar.xz" -C "$workdir/gmp-build"
cd "$workdir/gmp-build/gmp-6.3.0"
cp "$upstream/binding/gmp/tune/gmp-mparam.h" mpn/generic/gmp-mparam.h
python3 - <<'PY'
from pathlib import Path
p=Path('configure')
s=p.read_text()
assert 'abilist="standard"' in s
p.write_text(s.replace('abilist="standard"', 'abilist="standard longlong"\nlimb_longlong=longlong'))
PY
export CFLAGS='-O3 -Oz -fno-rtti -fno-exceptions -msimd128 -msse2'
export CXXFLAGS="$CFLAGS -std=c++11"
export CPPFLAGS="$CFLAGS -DNO_ASM"
export LDFLAGS="$CFLAGS"
export ABI='64 32' MPN_PATH=generic
HOST_CC=/usr/bin/clang emconfigure ./configure --build aarch64-apple-darwin --host none --prefix "$prefix" ABI=longlong --with-readline=no --enable-fft=yes --disable-cxx --enable-alloca=malloc-notreentrant
emmake make -j6 install MAKEINFO=true
unset CFLAGS CXXFLAGS CPPFLAGS LDFLAGS ABI MPN_PATH
cd "$workdir"
cp "$upstream/binding/src/entry.c" entry-mini.c
flags=(-I"$prefix/include" -O3 -Oz -flto -fno-rtti -fno-exceptions)
emcc "${flags[@]}" -c entry-mini.c -o entry-mini.o
link=(-L"$prefix/lib" "${flags[@]}" -s ENVIRONMENT=web,worker,node -s ALLOW_MEMORY_GROWTH=1 -s MODULARIZE=1 -s STANDALONE_WASM=1 -s ERROR_ON_UNDEFINED_SYMBOLS=1 -s AUTO_JS_LIBRARIES=0 -s ASSERTIONS=0 -s FILESYSTEM=0 --no-entry)
emcc "${link[@]}" -Wl,-Map,rebuilt-mini.map -lgmp entry-mini.o -o rebuilt-mini.js
cat >> entry-mini.c <<'EOF'

EMSCRIPTEN_KEEPALIVE int pi_rc_replacement_probe(void) { return 20261112; }
EOF
emcc "${flags[@]}" -c entry-mini.c -o modified-mini.o
emcc "${link[@]}" -Wl,-Map,modified-mini.map -lgmp modified-mini.o -o modified-mini.js
shasum -a 256 rebuilt-mini.wasm modified-mini.wasm
