#!/bin/bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
mkdir -p "${1:?Indica un directorio de trabajo nuevo}"
build=$(cd "$1" && pwd)
[ -z "$(ls -A "$build")" ] || { echo 'Usa un directorio vacío.' >&2; exit 1; }
cp "$root/sources/gmp-6.3.0.tar.xz" "$build/"
tar -xzf "$root/sources/gmp-wasm-1.3.2-4e372e5.tar.gz" -C "$build"
mkdir "$build/emsdk-local"
sdk="$build/emscripten-3.1.58.tar.xz"
if [ -n "${EMSDK_ARCHIVE:-}" ]; then
    cp "$EMSDK_ARCHIVE" "$sdk"
else
    curl -fsSL https://storage.googleapis.com/webassembly/emscripten-releases-builds/mac/a4d4afb626c5010f6ccda4638b8d77579a63782e/wasm-binaries-arm64.tar.xz -o "$sdk"
fi
printf '%s  %s\n' 7a9a15845257629b7602d15bdf7633a8e10472b0fa9b3d9ee7149938aa2f2039 "$sdk" | shasum -a 256 -c
tar -xJf "$sdk" -C "$build/emsdk-local"
python3 - "$build" <<'PY'
from pathlib import Path
import sys

# Emscripten 3.1.58 fuerza su Clang para las herramientas anfitrionas.
path = Path(sys.argv[1]) / 'emsdk-local/install/emscripten/tools/building.py'
original = "env['HOST_CC'] = CLANG_CC"
text = path.read_text()
assert text.count(original) == 1
path.write_text(text.replace(original, "env['HOST_CC'] = os.environ.get('HOST_CC', CLANG_CC)"))
PY
