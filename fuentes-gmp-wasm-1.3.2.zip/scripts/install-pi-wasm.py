from pathlib import Path
import argparse, base64, re, zlib

parser = argparse.ArgumentParser()
parser.add_argument('wasm', type=Path)
parser.add_argument('vendor', type=Path)
parser.add_argument('--bundle', required=True, type=Path)
parser.add_argument('--probe', action='store_true')
args = parser.parse_args()
wasm = args.wasm.read_bytes()
assert wasm.startswith(b'\0asm\x01\0\0\0')
compressor = zlib.compressobj(level=9, wbits=-15)
packed = base64.b64encode(compressor.compress(wasm) + compressor.flush()).decode()
bundle = args.bundle.read_text()
bundle, lengths = re.subn(r'const gmpWasmLength = \d+;', f'const gmpWasmLength = {len(wasm)};', bundle)
bundle, payloads = re.subn(r"const gmpWasm = '[^']+';", f"const gmpWasm = '{packed}';", bundle)
assert lengths == payloads == 1
if args.probe:
    before = '    exports._initialize();'
    assert bundle.count(before) == 1
    bundle = bundle.replace(before, before + '''
    const probe = exports.pi_rc_replacement_probe();
    if (probe !== 20261112) throw new Error('Unexpected WASM replacement');
    console.info('PI-RC: rebuilt modified WASM ' + probe);''')
args.vendor.write_text(bundle)
